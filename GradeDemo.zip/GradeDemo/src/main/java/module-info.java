module org.example.gradedemo {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.gradedemo to javafx.fxml;
    exports org.example.gradedemo;
}