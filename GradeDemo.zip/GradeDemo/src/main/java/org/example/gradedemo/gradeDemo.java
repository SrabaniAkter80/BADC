package org.example.gradedemo;
import java.util.Scanner;

public class gradeDemo {
    // 1. Grade check korar method
    public static String getGrade(double marks) {

        if (marks >= 80 && marks <= 100) {
            return "A";
        }
        else if (marks >= 60) {
            return "B";
        }
        else if (marks >= 40) {
            return "C";
        }
        else {
            return "F";
        }
    }

    public static void main(String[] args) {

        // 2. Grade print
        System.out.println(getGrade(90));
        System.out.println(getGrade(80));
        System.out.println(getGrade(79));
        System.out.println(getGrade(30));
        System.out.println(getGrade(50));

        // 3. Scanner create
        Scanner input = new Scanner(System.in);

        // 4. Marks input
        System.out.print("Enter Marks: ");
        double marks = input.nextDouble();

        // 5. Grade show
        System.out.println("Grade: " + getGrade(marks));

        // 6. Scanner close
        input.close();
    }
}

